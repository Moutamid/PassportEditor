package com.codevis.photoimageresizer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ImageView;

import com.codevis.photoimageresizer.databinding.ActivityGeneratePngBinding;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;

import java.io.File;
import java.util.Date;
import java.util.Objects;

public class GeneratePngActivity extends AppCompatActivity {
    File newFile;
    AdLoader adLoader;
    private ActivityGeneratePngBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityGeneratePngBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Objects.requireNonNull(getSupportActionBar()).setTitle("Jpg Converter");

        File oldFile = new File(getIntent().getStringExtra(Utils.OLD_FILE));
        newFile = new File(getIntent().getStringExtra(Utils.NEW_FILE));
        refreshGallery(newFile);

//        File pdfFile = new File(getIntent().getStringExtra(Utils.PDF_FILE));
        String fileName = getIntent().getStringExtra(Utils.FILE_NAME);

        binding.imageView3.setImageURI(Uri.fromFile(newFile));
        binding.fileName.setText(fileName);
        binding.fileSize.setText("File size: " + Utils.getFileSize(newFile.length()));
        binding.path.setText("Saved: " + newFile.getPath());
        MobileAds.initialize(getApplicationContext(), getString(R.string.admob_app_id));
        AdView mAdView = (AdView) findViewById(R.id.adView);
        ImageView placeImage = (ImageView) findViewById(R.id.placeholder);
        mAdView.setAdListener(new AdListener() {
            private void showToast(String message) {
                  
            }

            @Override
            public void onAdLoaded() {
                showToast("Ad loaded.");
                if (mAdView.getVisibility() == View.GONE) {
                    mAdView.setVisibility(View.VISIBLE);
                    placeImage.setVisibility(View.GONE);
                }
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                //  showToast(String.format("Ad failed to load with error code %d.", errorCode));

                mAdView.setVisibility(View.GONE);
                placeImage.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdOpened() {
                showToast("Ad opened.");
            }

            @Override
            public void onAdClosed() {
                showToast("Ad closed.");
            }

            @Override
            public void onAdLeftApplication() {
                showToast("Ad left application.");
            }
        });

        AdRequest request = new AdRequest.Builder().build();
//        mAdView.loadAd(request);

        adLoader = new AdLoader.Builder(GeneratePngActivity.this, getString(R.string.admob_native_id))
                .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        // Show the ad.
                        if (!adLoader.isLoading()) {
                            // The AdLoader is still loading ads.
                            // Expect more adLoaded or onAdFailedToLoad callbacks.
//                            Toast.makeText(MainActivity.this, "Loaded", Toast.LENGTH_SHORT).show();
                        }

                        if (isDestroyed()) {
                            nativeAd.destroy();
                            return;
                        }

                        NativeTemplateStyle styles = new NativeTemplateStyle
                                .Builder()
                                .withMainBackgroundColor(new ColorDrawable(Color.WHITE))
                                .build();
                        TemplateView template = findViewById(R.id.native_ad_temp);
                        template.setStyles(styles);
                        template.setNativeAd(nativeAd);
                    }
                })
                .withAdListener(new AdListener() {
                    @Override
                    public void onAdFailedToLoad(LoadAdError adError) {
                        // Handle the failure by logging, altering the UI, and so on.
                    }
                })
                .withNativeAdOptions(new NativeAdOptions.Builder()
                        // Methods in the NativeAdOptions.Builder class can be
                        // used here to specify individual options settings.
                        .build())
                .build();

        adLoader.loadAd(new AdRequest.Builder().build());

//        Date date = new Date();
        binding.tvDate.setText(new Date() + "");

        binding.imgShare.setOnClickListener(view ->
//                share(newFile.getPath())
        Utils.share(GeneratePngActivity.this, newFile.getPath(), Utils.TYPE_IMG));

        binding.imgOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open(newFile.getPath());
            }
        });
        binding.imgSave.setOnClickListener(v ->
                Utils.toast(getApplicationContext(), "Saved!"));

    }
    public void refreshGallery(File f) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Intent mediaScanIntent = new Intent(
                    Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            Uri fileUri = Uri.fromFile(f); //out is your output file
            mediaScanIntent.setData(fileUri);
            sendBroadcast(mediaScanIntent);
        } else {
            sendBroadcast(new Intent(
                    Intent.ACTION_MEDIA_MOUNTED,
                    Uri.parse("file://" + Environment.getExternalStorageDirectory())));
        }
    }
    public void open(String path) {
        Intent sharingIntent = new Intent(Intent.ACTION_VIEW);
        Uri screenshotUri = Uri.parse(path);
        sharingIntent.setType(Utils.TYPE_IMG);
        sharingIntent.putExtra(Intent.EXTRA_STREAM, screenshotUri);
        startActivity(Intent.createChooser(sharingIntent, ""));
    }

    /*@Override
    public void onBackPressed() {
        finish();
        startActivity(new Intent(GeneratePngActivity.this, MainActivity.class));
    }*/
}